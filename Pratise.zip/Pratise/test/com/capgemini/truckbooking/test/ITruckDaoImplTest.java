package com.capgemini.truckbooking.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Booking;
import com.cg.dao.Truckdao;
import com.cg.dao.TruckdaoImpl;
import com.cg.exception.NEWException;

public class ITruckDaoImplTest {
Truckdao dao=null;
	@Before
	public void setUp() throws Exception {
	dao=new TruckdaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	dao=null;
	}

	@Test
	public void testBookDetailsIsNotNull() {
	
		Booking booking = new Booking();
		booking.setCustId("A123465");
		booking.setCustMobile(9898789878l);
		booking.setTruckId(1002);
		booking.setNoOfTrucks(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate date = LocalDate.parse("2015-01-25", formatter);
		booking.setDateOfTransport(date);
  try {
	assertEquals(1017,dao.addTruck(booking));
} catch (NEWException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}



	}
	

}
