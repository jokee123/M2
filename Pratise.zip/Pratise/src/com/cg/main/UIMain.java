package com.cg.main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.Booking;
import com.cg.bean.Trucks;
import com.cg.exception.NEWException;
import com.cg.service.TruckService;
import com.cg.service.TruckServiceImpl;

public class UIMain {

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		boolean flag = false;
		do {

			Scanner scanner = new Scanner(System.in);
			System.out.println("Truck Booking");
			System.out.println("1.Book a truck");
			System.out.println("2.exit");
			try {
				Integer choice = scanner.nextInt();
				TruckService service = null;
				switch (choice) {
				case 1:
					flag = true;
					scanner.nextLine();
					System.out.println("Enter custId");

					String custId = scanner.nextLine();
					Booking booking = new Booking();
					booking.setCustId(custId);

					service = new TruckServiceImpl();
					
					boolean validateFlag = false;
					try {
						validateFlag = service.checkId(custId);
						System.out.println("The Truck details are.....");
						Trucks trucks1 = new Trucks();
						service = new TruckServiceImpl();
						List<Trucks> list2;
						list2 = service.allDetails();
						for (Trucks list3 : list2) {
							System.out.println(list3.getTruckID() + " " + list3.getTruckType() + " "
									+ list3.getOrigin() + " " + list3.getDestination() + " "
									+ list3.getCharges() + " " + list3.getAvailableNos());
						}
						
						if (validateFlag) {
							System.out.println("Enter the TruckId for availability");
							Integer truckId = scanner.nextInt();
							Trucks trucks = new Trucks();
							service = new TruckServiceImpl();
							List<Trucks> list;
							try {
								list = service.availability(truckId);
								for (Trucks list1 : list) {
									System.out.println(list1.getTruckID() + " " + list1.getTruckType() + " "
											+ list1.getOrigin() + " " + list1.getDestination() + " "
											+ list1.getCharges() + " " + list1.getAvailableNos());
								}

							} catch (NEWException e) {
								System.out.println("Wrong TruckId");
							}
							scanner.nextLine();
							System.out.println("Enter the custID");
							String CId = scanner.nextLine();
							System.out.println("Enter the mobile number");
							Long number = scanner.nextLong();
							System.out.println("Enter the truck Id");
							Integer TId = scanner.nextInt();
							System.out.println("Enter the number of trucks");
							Integer total = scanner.nextInt();
							scanner.nextLine();
							System.out.println("Enter the date of journey");
							String dateOfTransport = scanner.nextLine();
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
							LocalDate date = LocalDate.parse(dateOfTransport, formatter);
							Booking booking2 = new Booking();
							booking2.setCustId(CId);
							booking2.setCustMobile(number);
							booking2.setTruckId(TId);
							booking2.setNoOfTrucks(total);
							booking2.setDateOfTransport(date);
							service = new TruckServiceImpl();
							int bookId = service.addTruck(booking2);
							System.out.println("Truck is booked :" + bookId);

						} else {
							System.out.println("u are wrong");
						}
					} catch (NEWException e) {

						e.printStackTrace();
					}

					break;
				case 2:
					flag = true;
					System.out.println("Thank you");
					System.exit(0);
					break;
				default:
					System.err.println("Enter the input between 1 to 2");
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Plz enter digit");
			}

		} while (!flag);
	}

}
