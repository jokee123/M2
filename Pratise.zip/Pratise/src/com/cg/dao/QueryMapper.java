package com.cg.dao;

public interface QueryMapper {

	String display = "select * from truckdetails where truckid=? ";
	String insert = "insert into bookingdetails values (new_seq.nextval,?,?,?,?,?)";
	String select = "select * from truckdetails";
	String decrease = "update truckdetails SET availablenos=availablenos-? where truckid=? ";
	String getId = "select new_seq.CURRVAL from DUAL";
	String allDetails ="select * from truckdetails" ;

}
