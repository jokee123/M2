package com.cg.dao;

import java.util.List;

import com.cg.bean.Booking;
import com.cg.bean.Trucks;
import com.cg.exception.NEWException;

public interface Truckdao {

	List<Trucks> availability(Integer truckId) throws NEWException;

	int addTruck(Booking booking2) throws NEWException;

	List<Trucks> alldetails() throws NEWException;

}
