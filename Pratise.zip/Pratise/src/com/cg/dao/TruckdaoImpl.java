package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.cg.bean.Booking;
import com.cg.bean.Trucks;
import com.cg.exception.NEWException;
import com.cg.utility.JdbcUtility;

public class TruckdaoImpl implements Truckdao {
Connection connection=null;
PreparedStatement statement=null;
int result=0;
static org.apache.log4j.Logger logger=org.apache.log4j.Logger.getLogger(TruckdaoImpl.class);
ResultSet resultSet =null;
	@Override
	public List<Trucks> availability(Integer truckId) throws NEWException {
		connection=JdbcUtility.getConnection();
		logger.info("connection created");
		List<Trucks> list= new ArrayList<>();
		try {
			statement=connection.prepareStatement(QueryMapper.display);
			statement.setInt(1, truckId);
		resultSet=statement.executeQuery();
		resultSet.next();
		Integer truckID=resultSet.getInt(1);
		String truckType=resultSet.getString(2);
		String origin=resultSet.getString(3);
		String destination=resultSet.getString(4);
		Double charge=resultSet.getDouble(5);
		Integer availableNos=resultSet.getInt(6);
		Trucks trucks=new Trucks();
		trucks.setTruckID(truckID);
		trucks.setTruckType(truckType);
		trucks.setOrigin(origin);
		trucks.setDestination(destination);
		trucks.setCharges(charge);
		trucks.setAvailableNos(availableNos);
		list.add(trucks);
		} catch (SQLException e) {
			throw new NEWException("Wrong truck Id");
			//e.printStackTrace();
		}
		return list;
	}
	@Override
	public int addTruck(Booking booking2) throws NEWException {
		connection=JdbcUtility.getConnection();
		Integer bookId=0;
		boolean resultFlag=false;
		try {
			statement=connection.prepareStatement(QueryMapper.select);
			resultSet=statement.executeQuery();
			Integer id=booking2.getTruckId();
			
			Date date=Date.valueOf(booking2.getDateOfTransport());
			while(resultSet.next()) {
				if(id==resultSet.getInt("TRUCKID")&&resultSet.getInt("AVAILABLENOS")>0) {
					statement=connection.prepareStatement(QueryMapper.insert);
					statement.setString(1, booking2.getCustId());
					statement.setLong(2, booking2.getCustMobile());
					statement.setInt(3, booking2.getTruckId());
					statement.setInt(4, booking2.getNoOfTrucks());
					statement.setDate(5, date);
					statement.executeUpdate();
					
					System.out.println("11");
				
					statement=connection.prepareStatement(QueryMapper.decrease);
					statement.setInt(1, booking2.getNoOfTrucks());
					statement.setInt(2, booking2.getTruckId());					
					statement.executeUpdate();
					//resultSet.next();
					System.out.println("22");
			
					statement=connection.prepareStatement(QueryMapper.getId);
					
					resultSet=statement.executeQuery();
					resultSet.next();
					bookId=resultSet.getInt(1);
					
					resultFlag=true;
					
				}
				
			}
			if(resultFlag==false) {
				System.err.println("No product found");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return bookId;
	}
	@Override
	public List<Trucks> alldetails() throws NEWException {
		connection=JdbcUtility.getConnection();
		logger.info("connection created");
		List<Trucks> list= new ArrayList<>();
		try {
			statement=connection.prepareStatement(QueryMapper.allDetails);

		resultSet=statement.executeQuery();
		while(resultSet.next()) {
		Integer truckID=resultSet.getInt(1);
		String truckType=resultSet.getString(2);
		String origin=resultSet.getString(3);
		String destination=resultSet.getString(4);
		Double charge=resultSet.getDouble(5);
		Integer availableNos=resultSet.getInt(6);
		Trucks trucks=new Trucks();
		trucks.setTruckID(truckID);
		trucks.setTruckType(truckType);
		trucks.setOrigin(origin);
		trucks.setDestination(destination);
		trucks.setCharges(charge);
		trucks.setAvailableNos(availableNos);
		list.add(trucks);
		}
		} catch (SQLException e) {
			throw new NEWException("Wrong truck ");
			//e.printStackTrace();
		}
		return list;

		
	}

}
