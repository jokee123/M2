package com.cg.service;

import java.util.List;

import com.cg.bean.Booking;
import com.cg.bean.Trucks;
import com.cg.exception.NEWException;

public interface TruckService {

	boolean checkId(String custId) throws NEWException;

	List<Trucks> availability(Integer truckId) throws NEWException;

	int addTruck(Booking booking2) throws NEWException;

	List<Trucks> allDetails() throws NEWException;

}
