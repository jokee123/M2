package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.bean.Booking;
import com.cg.bean.Trucks;
import com.cg.dao.Truckdao;
import com.cg.dao.TruckdaoImpl;
import com.cg.exception.NEWException;
import com.cg.service.TruckService;

public class TruckServiceImpl implements TruckService {
Truckdao dao=new TruckdaoImpl();
	List<String> list=new ArrayList<>();

@Override
	public boolean checkId(String custId) throws NEWException{
		boolean validateFlag=false;
		if(!checkCustID(custId)) {
			list.add("Enter the valid custId");
		}
		/*if(!list.isEmpty()) {
			System.out.println("is empty");
			//throw new NEWException("Ur list is empty") ;
		}*/else {
			validateFlag=true;
		}
		
	return validateFlag;

	}
public boolean checkCustID(String custID) {
	
	String codeCheck="[A-Z]{1}[0-9]{6}";		
	return Pattern.matches(codeCheck, custID);
}
@Override
public List<Trucks> availability(Integer truckId) throws NEWException {
	
	return dao.availability(truckId);
}
@Override
public int addTruck(Booking booking2) throws NEWException {
	
	return dao.addTruck(booking2);
}
@Override
public List<Trucks> allDetails() throws NEWException {
	
	return dao.alldetails();
}


}
