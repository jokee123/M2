package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TBSException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.ITruckServiceImpl;

public class BookingClient {

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Scanner scanner = new Scanner(System.in);
		boolean choiceFlag = false;
		ITruckService service = null;

		do {
			System.out.println("*** Transport Truck Booking Online***");
			System.out.println("1.  Book Trucks ");
			System.out.println("2.  Exit        ");
			try {
				Integer choice = scanner.nextInt();
				switch (choice) {
				case 1:
					choiceFlag = true;
					System.out.println("***Truck Booking***");
					System.out.println("1.To Check for availability");
					System.out.println("2.To Book the Truck");
					System.out.println("3.exit");
					Integer nextChoice = scanner.nextInt();
					try {
						switch (nextChoice) {
						case 1:
							System.out.println("Enter the TruckID");
							Integer truckID = scanner.nextInt();
							
							service = new ITruckServiceImpl();
							
							System.out.println(truckID);
							try {
								
								List<TruckBean> list = service.truckAvailability(truckID);
								System.out.println(truckID);
								for (TruckBean list1 : list) {
									System.out.println(
											"TruckID     TruckType   Origin    Destination    Charges    AvailableNos");

									System.out.println(list1.getTruckID() + " , " + list1.getTruckType() + " , "
											+ list1.getOrigin() + " , " + list1.getDestination() + "  , "
											+ list1.getCharges() + " , " + list1.getAvailableNos());
								}

							} catch (TBSException e) {
								System.err.println(e.getMessage());
							}

							break;
						case 2:
							scanner.nextLine();
							choiceFlag = true;
							System.out.println("Enter the Customer ID");
							String custId = scanner.nextLine();
							System.out.println("Enter the Mobile Number");
							Long custMobile = scanner.nextLong();
							System.out.println("Enter the Truck ID");
							Integer truckId = scanner.nextInt();
							System.out.println("Enter the number of Trucks");
							Integer noOfTrucks = scanner.nextInt();
							scanner.nextLine();
							System.out.println("Enter the Date of Transport");
							String dateOfTransport = scanner.nextLine();
							
							
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
							

							LocalDate date = LocalDate.parse(dateOfTransport, formatter);
							BookingBean bookingBean = new BookingBean();
							bookingBean.setCustId(custId);
							bookingBean.setCustMobile(custMobile);
							bookingBean.setTruckId(truckId);
							bookingBean.setNoOfTrucks(noOfTrucks);
							bookingBean.setDateOfTransport(date);
							service = new ITruckServiceImpl();

							try {
								boolean validateFlag = service.validateFields(bookingBean);
								if (validateFlag) {
									int add = service.bookDetails(bookingBean);
									System.out.println("Thank you ..your booking Id is =" + add);

								}
							} catch (TBSException e) {
								System.out.println("check");
								System.out.println(e.getMessage());
								e.printStackTrace();
							}

							break;
						case 3:
							System.exit(0);
							System.out.println("Thank you..");
							break;
						default:
							System.out.println("Enter the Inputs between (1-3)");
							System.out.println("Enter the Input again");
							break;

						}

					} catch (InputMismatchException e) {

						System.err.println("Input should Contains Digits");
						System.out.println("Enter the inputs again");
					}

					break;
				case 2:
					choiceFlag = true;
					System.out.println("Thank you...");
					System.exit(0);

					break;
				default:
					choiceFlag = false;
					System.out.println("Enter the Inputs between (1-2)");
					System.out.println("Enter the Input again");

					break;

				}

			} catch (InputMismatchException e) {

				System.err.println("Input should Contains Digits");
				System.out.println("Enter the inputs again");
			}
			
		} while (!choiceFlag);
scanner.close();
	}

}
