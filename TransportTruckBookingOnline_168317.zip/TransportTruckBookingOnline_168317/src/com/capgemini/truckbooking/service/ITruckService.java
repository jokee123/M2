package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TBSException;

public interface ITruckService {

	
	boolean validateFields(BookingBean bookingBean) throws TBSException;

	int bookDetails(BookingBean bookingBean) throws TBSException;

	List<TruckBean> truckAvailability(Integer truckID)throws TBSException;

}
