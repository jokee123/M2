package com.capgemini.truckbooking.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.ITruckDaoImpl;
import com.capgemini.truckbooking.exception.TBSException;

public class ITruckServiceImpl implements ITruckService {
	ITruckDao dao = new ITruckDaoImpl();
	List<String> list = new ArrayList<>();

/*	@Override
	public List<TruckBean> truckAvailability(Integer truckID) throws TBSException {

		return dao.truckAvailability(truckID);
	}*/

	@Override
	public boolean validateFields(BookingBean bookingBean) throws TBSException {
		boolean validateFlag = false;

		if (!checkCustId(bookingBean.getCustId())) {
			list.add("Enter the custId as format");
		}
		if (!list.isEmpty()) {
			throw new TBSException("is Empty" + list);
		} else {
			validateFlag = true;
		}
		return validateFlag;
	}

	public boolean checkCustId(String CustId) {
		String codeRegEx = "[A-Z]{1}[0-9]{5}$";
		return Pattern.matches(codeRegEx, CustId);
	}
	/**
	 * method : validateFields argument :it's taking model object as an argument
	 * return type : this method returns the insertion to the user Author :Capgemini
	 * Date :21-Jan-2019
	 * 
	 **/
	@Override
	public int bookDetails(BookingBean bookingBean) throws TBSException {

		return dao.bookDetails(bookingBean);
	}

	@Override
	public List<TruckBean> truckAvailability(Integer truckID) throws TBSException {
		
		return dao.truckAvailability(truckID);
	}

}
