package com.capgemini.truckbooking.dao;

public interface QueryMapper {

	String getDetails = "SELECT * FROM TruckDetails";
	String setDetails="SELECT * FROM TruckDetails where truckid=?";
	
	String insertQuery = "INSERT INTO bookingdetails values(booking_id_seq.nextval,?,?,?,?,?) ";
	String decrease = "UPDATE truckdetails set availableNos=availablenos-? WHERE truckId=? ";
	String getId = "SELECT booking_id_seq.CURRVAL from dual";

}
